# Receitas AI

Sistema web simples feito com **Spring Boot + Spring AI**: um gerenciador de receitas com recursos de IA generativa.

## Requisitos atendidos

| Requisito | Como foi feito |
|---|---|
| Banco de dados | H2 em arquivo (`./data/receitasdb`) via Spring Data JPA. Console em `/h2-console` |
| Interface web | Thymeleaf + Bootstrap 5 (CDN) |
| Integração com GenAI | Spring AI (`ChatClient`) com o starter OpenAI (também funciona com APIs compatíveis) |
| Funcionalidades com GenAI | 3 funcionalidades, descritas abaixo |

## Funcionalidades

1. **CRUD de receitas**: listar, buscar por título, cadastrar, editar e excluir.
2. **Gerar receita com IA** (`/ia/gerar`): informe ingredientes e restrições; o modelo devolve uma receita em formato estruturado (`ReceitaGerada`, via `.entity(...)`). Você revisa e salva no banco.
3. **Análises da receita** (página de detalhe): versão mais saudável, substituições, estimativa nutricional e dicas do chef.
4. **Chat do chef** (`/ia/chat`): responde perguntas usando as receitas cadastradas no banco como contexto.

## Como executar

Pré-requisitos: **Java 17+** e **Maven 3.9+**.

```bash
# Linux / macOS
export OPENAI_API_KEY="sua-chave"
mvn spring-boot:run

# Windows (PowerShell)
$env:OPENAI_API_KEY="sua-chave"
mvn spring-boot:run
```

Abra http://localhost:8080

Duas receitas de exemplo são criadas na primeira execução. Sem a chave configurada, o sistema funciona normalmente, mas as telas de IA mostram uma mensagem de erro.

### Variáveis de ambiente opcionais

| Variável | Padrão |
|---|---|
| `OPENAI_MODEL` | `gpt-4o-mini` |
| `OPENAI_BASE_URL` | `https://api.openai.com` |
| `OPENAI_COMPLETIONS_PATH` | `/v1/chat/completions` |

Para usar outro provedor compatível com a API da OpenAI (exemplo: Gemini), ajuste a URL base, o caminho e o modelo:

```bash
export OPENAI_API_KEY="chave-do-provedor"
export OPENAI_BASE_URL="https://generativelanguage.googleapis.com"
export OPENAI_COMPLETIONS_PATH="/v1beta/openai/chat/completions"
export OPENAI_MODEL="gemini-2.0-flash"
```

## Estrutura

```
src/main/java/br/edu/receitasai
├── ReceitasAiApplication.java
├── ai/            ChefIaService (toda a integração Spring AI), AcaoIa, ReceitaGerada
├── config/        DataLoader (dados de exemplo)
├── controller/    ReceitaController (CRUD + análises), IaController (gerar + chat)
├── model/         Receita (entidade JPA)
└── repository/    ReceitaRepository
src/main/resources
├── application.properties
└── templates/     fragments, lista, form, detalhe, gerar, chat
```

## Observações

- A chave da API é lida de variável de ambiente; nunca a coloque no código.
- O conteúdo gerado por IA pode conter erros (especialmente a estimativa nutricional): a interface avisa e a receita gerada só é salva após a revisão do usuário.
