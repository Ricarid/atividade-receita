package br.edu.receitasai.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.LocalDateTime;

@Entity
public class Receita {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Informe o título")
    @Size(max = 120, message = "Máximo de 120 caracteres")
    private String titulo;

    @Size(max = 500, message = "Máximo de 500 caracteres")
    @Column(length = 500)
    private String descricao;

    @NotBlank(message = "Informe os ingredientes")
    @Size(max = 4000, message = "Máximo de 4000 caracteres")
    @Column(length = 4000)
    private String ingredientes;

    @NotBlank(message = "Informe o modo de preparo")
    @Size(max = 8000, message = "Máximo de 8000 caracteres")
    @Column(length = 8000)
    private String modoPreparo;

    @NotNull(message = "Informe o tempo de preparo")
    @Min(value = 1, message = "Mínimo de 1 minuto")
    private Integer tempoMinutos;

    @NotNull(message = "Informe as porções")
    @Min(value = 1, message = "Mínimo de 1 porção")
    private Integer porcoes;

    private LocalDateTime criadaEm;

    private boolean geradaPorIa;

    @PrePersist
    void aoCriar() {
        if (criadaEm == null) {
            criadaEm = LocalDateTime.now();
        }
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }

    public String getIngredientes() { return ingredientes; }
    public void setIngredientes(String ingredientes) { this.ingredientes = ingredientes; }

    public String getModoPreparo() { return modoPreparo; }
    public void setModoPreparo(String modoPreparo) { this.modoPreparo = modoPreparo; }

    public Integer getTempoMinutos() { return tempoMinutos; }
    public void setTempoMinutos(Integer tempoMinutos) { this.tempoMinutos = tempoMinutos; }

    public Integer getPorcoes() { return porcoes; }
    public void setPorcoes(Integer porcoes) { this.porcoes = porcoes; }

    public LocalDateTime getCriadaEm() { return criadaEm; }
    public void setCriadaEm(LocalDateTime criadaEm) { this.criadaEm = criadaEm; }

    public boolean isGeradaPorIa() { return geradaPorIa; }
    public void setGeradaPorIa(boolean geradaPorIa) { this.geradaPorIa = geradaPorIa; }
}
