package br.edu.receitasai.ai;

/**
 * Formato estruturado que o modelo deve devolver ao gerar uma receita.
 * O Spring AI converte a resposta JSON do modelo diretamente neste record.
 */
public record ReceitaGerada(
        String titulo,
        String descricao,
        String ingredientes,
        String modoPreparo,
        Integer tempoMinutos,
        Integer porcoes) {
}
