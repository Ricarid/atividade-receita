package br.edu.receitasai.config;

import br.edu.receitasai.model.Receita;
import br.edu.receitasai.repository.ReceitaRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/** Insere duas receitas de exemplo na primeira execução (banco vazio). */
@Component
public class DataLoader implements CommandLineRunner {

    private final ReceitaRepository repository;

    public DataLoader(ReceitaRepository repository) {
        this.repository = repository;
    }

    @Override
    public void run(String... args) {
        if (repository.count() > 0) {
            return;
        }

        repository.save(nova(
                "Omelete de queijo",
                "Rápido, proteico e perfeito para o café da manhã.",
                "3 ovos\n50 g de queijo mussarela\n1 colher (chá) de manteiga\nSal e pimenta a gosto",
                "1. Bata os ovos com sal e pimenta.\n2. Aqueça a manteiga em uma frigideira antiaderente.\n"
                        + "3. Despeje os ovos e deixe firmar em fogo baixo.\n4. Adicione o queijo, dobre ao meio e sirva.",
                10, 1));

        repository.save(nova(
                "Arroz com feijão simples",
                "O clássico brasileiro do dia a dia.",
                "1 xícara de arroz\n2 xícaras de água\n2 xícaras de feijão cozido\n2 dentes de alho\n1 colher (sopa) de óleo\nSal a gosto",
                "1. Refogue o alho no óleo e junte o arroz.\n2. Adicione a água e o sal e cozinhe até secar.\n"
                        + "3. Aqueça o feijão cozido com um pouco de alho e sirva junto.",
                40, 4));
    }

    private Receita nova(String titulo, String descricao, String ingredientes,
                         String modoPreparo, int tempo, int porcoes) {
        Receita r = new Receita();
        r.setTitulo(titulo);
        r.setDescricao(descricao);
        r.setIngredientes(ingredientes);
        r.setModoPreparo(modoPreparo);
        r.setTempoMinutos(tempo);
        r.setPorcoes(porcoes);
        return r;
    }
}
