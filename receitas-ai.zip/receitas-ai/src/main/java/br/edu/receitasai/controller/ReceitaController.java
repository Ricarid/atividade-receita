package br.edu.receitasai.controller;

import br.edu.receitasai.ai.AcaoIa;
import br.edu.receitasai.ai.ChefIaService;
import br.edu.receitasai.model.Receita;
import br.edu.receitasai.repository.ReceitaRepository;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
public class ReceitaController {

    private final ReceitaRepository repository;
    private final ChefIaService ia;

    public ReceitaController(ReceitaRepository repository, ChefIaService ia) {
        this.repository = repository;
        this.ia = ia;
    }

    @GetMapping("/")
    public String home() {
        return "redirect:/receitas";
    }

    @GetMapping("/receitas")
    public String listar(@RequestParam(required = false) String q, Model model) {
        List<Receita> receitas = (q == null || q.isBlank())
                ? repository.findAllByOrderByCriadaEmDesc()
                : repository.findByTituloContainingIgnoreCaseOrderByCriadaEmDesc(q.trim());
        model.addAttribute("receitas", receitas);
        model.addAttribute("q", q);
        return "lista";
    }

    @GetMapping("/receitas/nova")
    public String nova(Model model) {
        model.addAttribute("receita", new Receita());
        return "form";
    }

    @GetMapping("/receitas/{id}")
    public String detalhe(@PathVariable Long id, Model model) {
        model.addAttribute("receita", buscar(id));
        return "detalhe";
    }

    @GetMapping("/receitas/{id}/editar")
    public String editar(@PathVariable Long id, Model model) {
        model.addAttribute("receita", buscar(id));
        return "form";
    }

    @PostMapping("/receitas/salvar")
    public String salvar(@Valid @ModelAttribute("receita") Receita receita,
                         BindingResult result, RedirectAttributes redirect) {
        if (result.hasErrors()) {
            return "form";
        }
        // Preserva a data de criação ao editar (o formulário não envia esse campo).
        if (receita.getId() != null) {
            repository.findById(receita.getId())
                    .ifPresent(existente -> receita.setCriadaEm(existente.getCriadaEm()));
        }
        Receita salva = repository.save(receita);
        redirect.addFlashAttribute("sucesso", "Receita salva com sucesso!");
        return "redirect:/receitas/" + salva.getId();
    }

    @PostMapping("/receitas/{id}/excluir")
    public String excluir(@PathVariable Long id, RedirectAttributes redirect) {
        repository.deleteById(id);
        redirect.addFlashAttribute("sucesso", "Receita excluída.");
        return "redirect:/receitas";
    }

    /** Botões de IA da página de detalhe (versão saudável, substituições, nutrição, dicas). */
    @PostMapping("/receitas/{id}/ia")
    public String analisar(@PathVariable Long id, @RequestParam String acao, Model model) {
        Receita receita = buscar(id);
        model.addAttribute("receita", receita);

        AcaoIa acaoIa;
        try {
            acaoIa = AcaoIa.valueOf(acao.toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Ação de IA inválida");
        }

        model.addAttribute("tituloIa", acaoIa.getTitulo());
        try {
            model.addAttribute("resultadoIa", ia.analisar(receita, acaoIa));
        } catch (Exception e) {
            model.addAttribute("erroIa", mensagemErro(e));
        }
        return "detalhe";
    }

    private Receita buscar(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Receita não encontrada"));
    }

    static String mensagemErro(Exception e) {
        return "Não foi possível obter resposta da IA. Verifique a variável OPENAI_API_KEY e sua conexão. "
                + "(" + e.getClass().getSimpleName() + ")";
    }
}
