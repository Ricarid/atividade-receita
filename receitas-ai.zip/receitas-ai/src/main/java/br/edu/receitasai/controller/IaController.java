package br.edu.receitasai.controller;

import br.edu.receitasai.ai.ChefIaService;
import br.edu.receitasai.ai.ReceitaGerada;
import br.edu.receitasai.model.Receita;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class IaController {

    private final ChefIaService ia;

    public IaController(ChefIaService ia) {
        this.ia = ia;
    }

    // ---------- Gerar receita a partir de ingredientes ----------

    @GetMapping("/ia/gerar")
    public String formGerar() {
        return "gerar";
    }

    @PostMapping("/ia/gerar")
    public String gerar(@RequestParam String ingredientes,
                        @RequestParam(required = false) String restricoes,
                        Model model) {
        model.addAttribute("ingredientes", ingredientes);
        model.addAttribute("restricoes", restricoes);

        if (ingredientes == null || ingredientes.isBlank()) {
            model.addAttribute("erro", "Informe pelo menos um ingrediente.");
            return "gerar";
        }

        try {
            ReceitaGerada g = ia.gerarReceita(ingredientes, restricoes);

            Receita receita = new Receita();
            receita.setTitulo(g.titulo());
            receita.setDescricao(g.descricao());
            receita.setIngredientes(g.ingredientes());
            receita.setModoPreparo(g.modoPreparo());
            receita.setTempoMinutos(g.tempoMinutos());
            receita.setPorcoes(g.porcoes());
            receita.setGeradaPorIa(true);

            model.addAttribute("receita", receita);
            model.addAttribute("aviso", "Receita gerada pela IA. Revise os dados e clique em Salvar para guardá-la no banco.");
            return "form";
        } catch (Exception e) {
            model.addAttribute("erro", ReceitaController.mensagemErro(e));
            return "gerar";
        }
    }

    // ---------- Chat com o chef (usa as receitas do banco como contexto) ----------

    @GetMapping("/ia/chat")
    public String chat() {
        return "chat";
    }

    @PostMapping("/ia/chat")
    public String perguntar(@RequestParam String pergunta, Model model) {
        model.addAttribute("pergunta", pergunta);

        if (pergunta == null || pergunta.isBlank()) {
            model.addAttribute("erro", "Digite uma pergunta.");
            return "chat";
        }

        try {
            model.addAttribute("resposta", ia.perguntar(pergunta));
        } catch (Exception e) {
            model.addAttribute("erro", ReceitaController.mensagemErro(e));
        }
        return "chat";
    }
}
