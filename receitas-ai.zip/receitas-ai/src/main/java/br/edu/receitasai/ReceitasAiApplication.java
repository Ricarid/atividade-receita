package br.edu.receitasai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReceitasAiApplication {

    public static void main(String[] args) {
        SpringApplication.run(ReceitasAiApplication.class, args);
    }
}
