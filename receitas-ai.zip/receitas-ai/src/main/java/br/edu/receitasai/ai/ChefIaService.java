package br.edu.receitasai.ai;

import br.edu.receitasai.model.Receita;
import br.edu.receitasai.repository.ReceitaRepository;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Concentra todo o uso de GenAI da aplicação via Spring AI (ChatClient).
 */
@Service
public class ChefIaService {

    private static final String PERSONA = """
            Você é um chef de cozinha experiente, simpático e objetivo.
            Responda sempre em português do Brasil.
            Responda em texto simples, sem markdown (sem #, ** ou tabelas); use apenas quebras de linha e hífens para listas.
            Se a pergunta não for sobre culinária, diga educadamente que só pode ajudar com cozinha.
            """;

    private final ChatClient chatClient;
    private final ReceitaRepository repository;

    public ChefIaService(ChatClient.Builder builder, ReceitaRepository repository) {
        this.chatClient = builder.defaultSystem(PERSONA).build();
        this.repository = repository;
    }

    /** Funcionalidade 1: gera uma receita completa (saída estruturada) a partir dos ingredientes. */
    public ReceitaGerada gerarReceita(String ingredientes, String restricoes) {
        String restricao = (restricoes == null || restricoes.isBlank()) ? "nenhuma" : restricoes;

        return chatClient.prompt()
                .user(u -> u.text("""
                                Crie uma receita usando principalmente estes ingredientes: {ingredientes}.
                                Restrições alimentares: {restricoes}.
                                No campo "ingredientes" coloque um ingrediente por linha, com quantidade.
                                No campo "modoPreparo" coloque os passos numerados, um por linha.
                                No campo "tempoMinutos" e "porcoes" use apenas números inteiros.
                                """)
                        .param("ingredientes", ingredientes)
                        .param("restricoes", restricao))
                .call()
                .entity(ReceitaGerada.class);
    }

    /** Funcionalidade 2: analisa uma receita já salva no banco (versão saudável, substituições etc.). */
    public String analisar(Receita receita, AcaoIa acao) {
        return chatClient.prompt()
                .user(u -> u.text("""
                                {instrucao}

                                Receita: {titulo}
                                Porções: {porcoes}
                                Ingredientes:
                                {ingredientes}

                                Modo de preparo:
                                {modoPreparo}
                                """)
                        .param("instrucao", acao.getInstrucao())
                        .param("titulo", receita.getTitulo())
                        .param("porcoes", String.valueOf(receita.getPorcoes()))
                        .param("ingredientes", receita.getIngredientes())
                        .param("modoPreparo", receita.getModoPreparo()))
                .call()
                .content();
    }

    /** Funcionalidade 3: chat que responde usando as receitas cadastradas no banco como contexto. */
    public String perguntar(String pergunta) {
        List<Receita> receitas = repository.findAllByOrderByCriadaEmDesc();

        String contexto = receitas.isEmpty()
                ? "(nenhuma receita cadastrada)"
                : receitas.stream()
                        .limit(30)
                        .map(r -> "- " + r.getTitulo() + " | ingredientes: "
                                + r.getIngredientes().replace("\n", ", "))
                        .collect(Collectors.joining("\n"));

        return chatClient.prompt()
                .system(s -> s.text(PERSONA + """

                                Receitas cadastradas pelo usuário (use-as como base quando fizer sentido):
                                {receitas}
                                """)
                        .param("receitas", contexto))
                .user(pergunta)
                .call()
                .content();
    }
}
