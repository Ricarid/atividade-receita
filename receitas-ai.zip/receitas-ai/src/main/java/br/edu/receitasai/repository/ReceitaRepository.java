package br.edu.receitasai.repository;

import br.edu.receitasai.model.Receita;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ReceitaRepository extends JpaRepository<Receita, Long> {

    List<Receita> findAllByOrderByCriadaEmDesc();

    List<Receita> findByTituloContainingIgnoreCaseOrderByCriadaEmDesc(String titulo);
}
