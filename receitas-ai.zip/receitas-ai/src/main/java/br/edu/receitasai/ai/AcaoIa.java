package br.edu.receitasai.ai;

public enum AcaoIa {

    SAUDAVEL("Versão mais saudável",
            "Sugira uma versão mais saudável desta receita, indicando o que trocar ou reduzir e por quê."),
    SUBSTITUICOES("Substituições de ingredientes",
            "Para cada ingrediente principal, sugira uma substituição possível "
                    + "(por exemplo: sem glúten, sem lactose ou vegana) e explique o efeito no resultado."),
    NUTRICIONAL("Estimativa nutricional",
            "Estime calorias, proteínas, carboidratos e gorduras por porção. "
                    + "Deixe claro que os valores são apenas estimativas aproximadas."),
    DICAS("Dicas do chef",
            "Dê dicas de preparo, de apresentação e de armazenamento desta receita.");

    private final String titulo;
    private final String instrucao;

    AcaoIa(String titulo, String instrucao) {
        this.titulo = titulo;
        this.instrucao = instrucao;
    }

    public String getTitulo() { return titulo; }

    public String getInstrucao() { return instrucao; }
}
